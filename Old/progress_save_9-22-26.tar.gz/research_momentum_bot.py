"""
research_momentum_bot.py
Autonomous Quantitative Momentum Options Bot
Production Grade Execution Engine with VIC Macro Gatekeeper & LEARN Telemetry
"""

from datetime import date, datetime, timedelta
import json
import math
import os
import time
from zoneinfo import ZoneInfo
from dotenv import load_dotenv
import numpy as np
import pandas as pd
from scipy.stats import norm
from safe_yf import safe_download, safe_fast_price

from alpaca.data.historical.option import OptionHistoricalDataClient
from alpaca.data.requests import OptionSnapshotRequest
from alpaca.trading.client import TradingClient
from alpaca.trading.enums import ContractType, OrderSide, TimeInForce
from alpaca.trading.requests import GetOptionContractsRequest, LimitOrderRequest

# -------------------------------------------------------------
# 1. Environment & API Clients
# -------------------------------------------------------------
for path in [
    "/Users/vic/Desktop/Coding/.env",
    "/Users/vic/trading_bot/.env",
    ".env",
]:
    if os.path.exists(path):
        load_dotenv(path)

API_KEY = os.getenv("APCA_API_KEY_ID") or os.getenv("ALPACA_API_KEY")
SECRET_KEY = os.getenv("APCA_API_SECRET_KEY") or os.getenv("ALPACA_SECRET_KEY")

if API_KEY and SECRET_KEY:
    trading_client = TradingClient(API_KEY, SECRET_KEY, paper=True)
    data_client = OptionHistoricalDataClient(API_KEY, SECRET_KEY)
else:
    trading_client = None
    data_client = None

# -------------------------------------------------------------
# Quantitative, Logging, Learning & AI Executive Layers
# -------------------------------------------------------------
import alpha_engine as ae
import learn_tracker as lt
import market_barometer as mb
import option_engine as oe
import research_logger as rl

try:
    from ai_manager import AITradingManager
    vic_officer = AITradingManager()
except ImportError:
    vic_officer = None

# -------------------------------------------------------------
# 2. Institutional Universe & Risk Parameters
# -------------------------------------------------------------
EASTERN_TZ = ZoneInfo("America/New_York")
UNIVERSE = [
    "SPY", "QQQ", "SMH", "NVDA", "AMD", 
    "MSFT", "AAPL", "AMZN", "COIN", "META", "TSLA"
]

SECTOR_MAP = {
    "SPY": "SPY",
    "QQQ": "SPY",
    "SMH": "QQQ",
    "NVDA": "SMH",
    "AMD": "SMH",
    "MSFT": "QQQ",
    "AAPL": "QQQ",
    "AMZN": "QQQ",
    "META": "QQQ",
    "TSLA": "QQQ",
    "COIN": "QQQ",
}

RISK_PER_TRADE_PERCENT = 0.005
MAX_CONCURRENT_POSITIONS = 3
TARGET_DELTA = 0.65
DELTA_TOLERANCE = 0.10
MAX_RELATIVE_SPREAD = 0.06
MIN_DTE = 1
MAX_DTE = 7

MAX_CONTRACTS_PER_TICKER = 10
ENTRY_CUTOFF_TIME = "15:00:00"
FLATTEN_TIME_STR = "15:45:00"
ORDER_MUTEX_SECONDS = 60

active_trades = {}
pending_setups = {}
order_cooldown_tracker = {}

TELEMETRY_FILE = "bot_telemetry.json"


def record_telemetry(ticker: str, stage: str, reason: str, details: dict = None):
    """Writes bot decision state to a fast local JSON cache (sub-millisecond)."""
    telemetry = {}
    if os.path.exists(TELEMETRY_FILE):
        try:
            with open(TELEMETRY_FILE, "r") as f:
                telemetry = json.load(f)
        except Exception:
            telemetry = {}

    telemetry[ticker] = {
        "timestamp": datetime.now(EASTERN_TZ).strftime("%H:%M:%S ET"),
        "stage": stage,
        "reason": reason,
        "details": details or {},
    }

    try:
        with open(TELEMETRY_FILE, "w") as f:
            json.dump(telemetry, f, indent=2)
    except Exception:
        pass


def calculate_delta(
    spot: float,
    strike: float,
    dte_days: float,
    is_call: bool = True,
    iv: float = 0.22,
    r: float = 0.045,
) -> float:
    t = max(dte_days, 0.5) / 365.0
    d1 = (math.log(spot / strike) + (r + 0.5 * iv**2) * t) / (iv * math.sqrt(t))
    return float(norm.cdf(d1)) if is_call else float(norm.cdf(d1) - 1.0)


def is_regular_market_hours() -> bool:
    if trading_client:
        try:
            clock = trading_client.get_clock()
            return clock.is_open
        except Exception:
            pass

    now = datetime.now(EASTERN_TZ)
    if now.weekday() >= 5:
        return False
    market_open = now.replace(hour=9, minute=30, second=0, microsecond=0)
    market_close = now.replace(hour=16, minute=0, second=0, microsecond=0)
    return market_open <= now <= market_close


def can_enter_new_trade(ticker: str) -> tuple[bool, str]:
    now_et = datetime.now(EASTERN_TZ)
    now_time_str = now_et.strftime("%H:%M:%S")

    if now_time_str >= ENTRY_CUTOFF_TIME:
        return False, f"Past 3:00 PM EDT cutoff ({now_time_str})"

    last_order_ts = order_cooldown_tracker.get(ticker, 0)
    elapsed = time.time() - last_order_ts
    if elapsed < ORDER_MUTEX_SECONDS:
        return False, f"Cooldown active ({ORDER_MUTEX_SECONDS - elapsed:.1f}s remaining)"

    return True, "Approved"


def fetch_underlying_features(symbol: str):
    """Fetches bars via rate-limited, cached safe_download layer."""
    df = safe_download(symbol, period="5d", interval="15m")
    if df.empty or len(df) < 25:
        return None

    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)

    if df.index.tz is None:
        df.index = df.index.tz_localize("UTC").tz_convert(EASTERN_TZ)
    else:
        df.index = df.index.tz_convert(EASTERN_TZ)

    df["EMA20"] = df["Close"].ewm(span=20, adjust=False).mean()
    df["EMA20_Slope"] = df["EMA20"] - df["EMA20"].shift(1)

    tr1 = df["High"] - df["Low"]
    tr2 = (df["High"] - df["Close"].shift()).abs()
    tr3 = (df["Low"] - df["Close"].shift()).abs()
    df["TR"] = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    df["ATR14"] = df["TR"].rolling(window=14).mean()

    today_date = df.index[-1].date()
    df_today = df[df.index.date == today_date].copy()
    if len(df_today) < 2:
        return None

    cum_vol = df_today["Volume"].cumsum()
    cum_pv = (
        (df_today["High"] + df_today["Low"] + df_today["Close"])
        / 3.0
        * df_today["Volume"]
    ).cumsum()
    df_today["VWAP"] = cum_pv / np.where(cum_vol == 0, 1, cum_vol)

    orb_bars = df_today.between_time("09:30", "09:59")
    if len(orb_bars) < 2:
        orb_bars = df_today.iloc[:2]

    orb_high = float(orb_bars["High"].max())
    orb_low = float(orb_bars["Low"].min())
    latest = df_today.iloc[-1]

    open_p = float(latest["Open"])
    high_p = float(latest["High"])
    low_p = float(latest["Low"])
    close_p = float(latest["Close"])
    total_range = max(high_p - low_p, 0.01)
    body_pct = (abs(close_p - open_p) / total_range) * 100.0
    close_loc = (close_p - low_p) / total_range

    return {
        "close": close_p,
        "vwap": float(latest["VWAP"]),
        "orb_high": orb_high,
        "orb_low": orb_low,
        "ema20": float(latest["EMA20"]),
        "ema20_slope": float(latest["EMA20_Slope"]),
        "atr": float(latest["ATR14"]),
        "body_pct": body_pct,
        "close_location": close_loc,
    }


def select_research_contract(
    symbol: str, spot: float, contract_type: ContractType
):
    if not trading_client or not data_client:
        return None

    today = date.today()
    is_call = contract_type == ContractType.CALL
    strike_min = spot * 0.95 if is_call else spot * 0.98
    strike_max = spot * 1.02 if is_call else spot * 1.05

    req = GetOptionContractsRequest(
        underlying_symbols=[symbol],
        status="active",
        type=contract_type,
        expiration_date_gte=today + timedelta(days=MIN_DTE),
        expiration_date_lte=today + timedelta(days=MAX_DTE),
        strike_price_gte=str(round(strike_min, 2)),
        strike_price_lte=str(round(strike_max, 2)),
        limit=50,
    )

    try:
        res = trading_client.get_option_contracts(req)
        if not res.option_contracts:
            return None

        symbols = [c.symbol for c in res.option_contracts]
        snaps = data_client.get_option_snapshot(
            OptionSnapshotRequest(symbol_or_symbols=symbols)
        )

        candidates = []
        for c in res.option_contracts:
            snap = snaps.get(c.symbol)
            if not snap or not snap.latest_quote:
                continue

            bid = float(snap.latest_quote.bid_price)
            ask = float(snap.latest_quote.ask_price)
            if bid <= 0.05 or ask <= 0:
                continue

            mid = round((bid + ask) / 2.0, 2)
            rel_spread = (ask - bid) / mid
            dte = (c.expiration_date - today).days
            strike = float(c.strike_price)
            delta = calculate_delta(spot, strike, dte, is_call=is_call)

            if rel_spread > MAX_RELATIVE_SPREAD:
                continue
            if abs(abs(delta) - TARGET_DELTA) > DELTA_TOLERANCE:
                continue

            candidates.append({
                "symbol": c.symbol,
                "strike": strike,
                "delta": abs(delta),
                "bid": bid,
                "ask": ask,
                "mid": mid,
                "spread_pct": rel_spread,
                "dte": dte,
                "expiration": str(c.expiration_date),
            })

        if not candidates:
            return None

        return min(candidates, key=lambda x: abs(x["delta"] - TARGET_DELTA))

    except Exception as e:
        print(f"⚠️ Contract selection error on {symbol}: {e}")
        return None


def calculate_position_qty(
    equity: float, estimated_loss_per_contract: float
) -> int:
    risk_budget = equity * RISK_PER_TRADE_PERCENT
    raw_qty = int(risk_budget // max(estimated_loss_per_contract, 50.0))
    return max(1, min(raw_qty, MAX_CONTRACTS_PER_TICKER))


def check_orb_revalidation(
    symbol: str, setup_state: dict, latest_15m_close: float, max_wait_bars: int = 2
) -> dict:
    if setup_state.get("status") != "ARMED":
        return setup_state

    direction = setup_state.get("direction")
    orb_high = setup_state.get("orb_high", 0.0)
    orb_low = setup_state.get("orb_low", 0.0)
    bars_elapsed = setup_state.get("bars_elapsed", 0) + 1
    setup_state["bars_elapsed"] = bars_elapsed

    if direction == "CALL" and latest_15m_close < orb_high:
        setup_state["status"] = "DISARMED"
        setup_state["audit_reason"] = (
            f"Failed breakout: 15m closed back inside range at ${latest_15m_close:.2f} "
            f"(ORB High: ${orb_high:.2f})"
        )
        return setup_state

    if direction == "PUT" and latest_15m_close > orb_low:
        setup_state["status"] = "DISARMED"
        setup_state["audit_reason"] = (
            f"Failed breakdown: 15m closed back inside range at ${latest_15m_close:.2f} "
            f"(ORB Low: ${orb_low:.2f})"
        )
        return setup_state

    if bars_elapsed >= max_wait_bars:
        setup_state["status"] = "EXPIRED"
        setup_state["audit_reason"] = (
            f"TTL Expired: Unfilled after {bars_elapsed} bars (30m window)"
        )
        return setup_state

    return setup_state


def run_continuous_risk_loop():
    now_str = datetime.now(EASTERN_TZ).strftime("%H:%M:%S")

    # 1. Auto-Flatten at 15:45 EDT
    if now_str >= FLATTEN_TIME_STR:
        if trading_client:
            try:
                positions = trading_client.get_all_positions()
                if positions:
                    print(
                        f"\n🛑 [EOD CUTOFF] {now_str} >= {FLATTEN_TIME_STR}. Liquidating open intraday trades."
                    )
                    trading_client.close_all_positions(cancel_orders=True)
                    for sym in active_trades:
                        record_telemetry(sym, "⚪ FLATTENED", "EOD auto-flatten reached (15:45 ET)")
                    active_trades.clear()
                    pending_setups.clear()
            except Exception as e:
                print(f"⚠️ Flatten error: {e}")
        return

    # 2. Revalidate and purge pending / armed setups
    for sym in list(pending_setups.keys()):
        setup = pending_setups[sym]
        feat = fetch_underlying_features(sym)
        if not feat:
            continue

        updated = check_orb_revalidation(sym, setup, feat["close"])
        if updated.get("status") in ["DISARMED", "EXPIRED"]:
            print(f"\n⚪ [{updated['status']}] {sym} - {updated.get('audit_reason')}")
            order_id = updated.get("order_id")
            if order_id and trading_client:
                try:
                    trading_client.cancel_order_by_id(order_id)
                    print(f"   🗑️ Canceled pending Alpaca order {order_id} for {sym}")
                except Exception as ce:
                    print(f"   ⚠️ Could not cancel order {order_id}: {ce}")
            record_telemetry(sym, f"⚪ {updated['status']}", updated.get("audit_reason", "Setup invalidated"))
            del pending_setups[sym]

    # 3. Synchronize with Alpaca Positions
    if trading_client:
        try:
            positions = trading_client.get_all_positions()
            for p in positions:
                for sym in UNIVERSE:
                    if sym in p.symbol and sym in pending_setups:
                        trade_info = pending_setups.pop(sym)
                        trade_info["qty"] = p.qty
                        trade_info["avg_entry"] = p.avg_entry_price
                        active_trades[sym] = trade_info
                        record_telemetry(
                            sym, 
                            "🟢 EXECUTED / ACTIVE (10s)", 
                            f"Filled {p.qty} contracts @ ${float(p.avg_entry_price):.2f}. Stop: ${trade_info['stop']:.2f} | Target: ${trade_info['target']:.2f}",
                            {"contract": p.symbol, "levels": f"-1R: ${trade_info['stop']:.2f} | +2R: ${trade_info['target']:.2f}"}
                        )
        except Exception:
            pass

    # 4. Evaluate active open positions with safe rate-limited pricing
    for sym in list(active_trades.keys()):
        trade = active_trades[sym]
        try:
            current_spot = safe_fast_price(sym)
            if current_spot <= 0:
                continue

            hit_stop = (
                (current_spot <= trade["stop"])
                if trade["direction"] == "CALL"
                else (current_spot >= trade["stop"])
            )
            hit_target = (
                (current_spot >= trade["target"])
                if trade["direction"] == "CALL"
                else (current_spot <= trade["target"])
            )

            record_telemetry(
                sym, 
                "🟢 EXECUTED / ACTIVE (10s)", 
                f"Spot: ${current_spot:.2f} | Trailing 10s loop active",
                {"contract": trade["contract"], "levels": f"Stop: ${trade['stop']:.2f} | Target: ${trade['target']:.2f}"}
            )

            if hit_stop or hit_target:
                tag = "🎯 [TARGET HIT]" if hit_target else "🚨 [STOP HIT]"
                print(f"\n{tag} {sym} @ ${current_spot:.2f} (Exit: {trade['contract']})")
                if trading_client:
                    trading_client.close_position(trade["contract"])

                result_r = 2.0 if hit_target else -1.0
                record_telemetry(sym, "⚪ CLOSED", f"{tag} Exit at ${current_spot:.2f} ({result_r:+.1f}R)")

                rl.log_shadow_record(
                    ticker=sym,
                    action="TRADE_EXIT",
                    spot_price=current_spot,
                    orb_high=trade.get("orb_h", current_spot),
                    orb_low=trade.get("orb_l", current_spot),
                    vwap=current_spot,
                    ema20=current_spot,
                    ema_slope=0.0,
                    atr=trade.get("atr", 1.0),
                    rvol_ratio=1.0,
                    rvol_percentile=50.0,
                    rvol_zscore=0.0,
                    spy_score=50.0,
                    qqq_score=50.0,
                    sector_etf=SECTOR_MAP.get(sym, "SPY"),
                    sector_score=50.0,
                    rs_market=0.0,
                    rs_sector=0.0,
                    volatility_regime="NORMAL",
                    alpha_score=trade.get("alpha_score", 50.0),
                    alpha_breakdown={},
                    vic_verdict=trade.get("vic_verdict", "PERMIT"),
                    vic_mode=trade.get("vic_mode", "SHADOW"),
                    vic_sizing_scalar=trade.get("vic_sizing_scalar", 1.0),
                    vic_reason_code=trade.get("vic_reason_code", "NONE"),
                    vic_reason=trade.get("vic_reason", ""),
                    vic_obstacle_dist_r=trade.get("vic_obstacle_dist_r"),
                    vic_1h_bar_ts=trade.get("vic_1h_bar_ts"),
                    vic_4h_bar_ts=trade.get("vic_4h_bar_ts"),
                    contract_symbol=trade["contract"],
                    delta=TARGET_DELTA,
                    dte=trade.get("dte", 5),
                    bid=trade.get("entry_mid", 1.0),
                    ask=trade.get("entry_mid", 1.0),
                    spread_pct=trade.get("spread_pct", 2.0),
                    execution_score=trade.get("exec_score", 85.0),
                    trade_taken=True,
                    entry_price=trade["entry_spot"],
                    exit_price=current_spot,
                    result_r=result_r,
                )
                del active_trades[sym]

        except Exception as err:
            print(f"⚠️ Monitoring check error on {sym}: {err}")


def scan_alpha_signals():
    now_et = datetime.now(EASTERN_TZ)
    if now_et.hour == 9 and now_et.minute < 30:
        return

    if now_et.strftime("%H:%M:%S") >= ENTRY_CUTOFF_TIME:
        print(f"⏸️ [ENTRY SHUTDOWN] Time ({now_et.strftime('%H:%M:%S')}) >= {ENTRY_CUTOFF_TIME}. No new setups allowed.")
        return

    print(f"\n========================================================")
    print(f"📈 Scanning Universe at: {now_et.strftime('%Y-%m-%d %H:%M:%S ET')}")
    print(f"========================================================")

    equity = 100000.0
    held_symbols = set()
    if trading_client:
        try:
            account = trading_client.get_account()
            equity = float(account.equity)
            positions = trading_client.get_all_positions()
            for p in positions:
                held_symbols.add(p.symbol)
            if len(positions) >= MAX_CONCURRENT_POSITIONS:
                print(f"⚪ Max positions ({MAX_CONCURRENT_POSITIONS}) reached. Skipping entries.")
                return
        except Exception as e:
            print(f"⚠️ Account fetch error: {e}")
            return

    for ticker in UNIVERSE:
        if ticker in active_trades or ticker in pending_setups:
            continue

        feat = fetch_underlying_features(ticker)
        if not feat:
            continue

        spot = feat["close"]
        vwap = feat["vwap"]
        orb_h = feat["orb_high"]
        orb_l = feat["orb_low"]
        slope = feat["ema20_slope"]
        atr = feat["atr"]

        alpha_info = ae.compute_alpha_score(ticker)
        alpha_score = alpha_info.get("alpha_score", 50.0)
        bd = alpha_info.get("breakdown", {})
        rvol = alpha_info.get("rvol_metrics", {})
        reg = alpha_info.get("regime_metrics", {})

        is_bullish = (spot > orb_h) and (spot > vwap) and (slope > 0)
        is_bearish = (spot < orb_l) and (spot < vwap) and (slope < 0)

        if not (is_bullish or is_bearish):
            reason_str = f"Inside 30m ORB [${orb_l:.2f} - ${orb_h:.2f}]" if (spot <= orb_h and spot >= orb_l) else f"EMA Slope flat/chop ({slope:+.3f})"
            record_telemetry(ticker, "⚪ SCANNING", reason_str, {"levels": f"ORB: ${orb_l:.2f} - ${orb_h:.2f}"})
            continue

        direction = "CALL" if is_bullish else "PUT"
        contract_type = ContractType.CALL if is_bullish else ContractType.PUT

        if is_bullish:
            stop_level = round(spot - (1.0 * atr), 2)
            target_level = round(spot + (2.0 * atr), 2)
        else:
            stop_level = round(spot + (1.0 * atr), 2)
            target_level = round(spot - (2.0 * atr), 2)

        vic_clearance = mb.evaluate_macro_clearance(
            ticker=ticker,
            direction=direction,
            spot_price=spot,
            stop_price=stop_level,
            target_price=target_level,
        )

        match = select_research_contract(ticker, spot, contract_type)
        can_enter, entry_reason = can_enter_new_trade(ticker)

        scalar = vic_clearance["sizing_scalar"] if vic_clearance["mode"] == "ENFORCE" else 1.0
        base_qty = calculate_position_qty(
            equity, estimated_loss_per_contract=atr * 100 * TARGET_DELTA
        )
        qty = math.floor(base_qty * scalar)
        assigned_sector = SECTOR_MAP.get(ticker, reg.get("sector_etf", "SPY"))

        if vic_clearance["mode"] == "ENFORCE" and vic_clearance["verdict"] == "VETO":
            final_state = "VETOED"
            hero_decision = "APPROVE"
            decision_code = f"VIC_MACRO_VETO: {vic_clearance.get('reason_code')}"
            record_telemetry(ticker, "🔴 VETOED", decision_code)
        elif alpha_score < 70.0:
            final_state = "REJECTED"
            hero_decision = "REJECT"
            decision_code = f"ALPHA_BELOW_THRESHOLD ({alpha_score:.0f}/100)"
            record_telemetry(ticker, "❌ REJECTED", decision_code)
        elif not can_enter:
            final_state = "BLOCKED"
            hero_decision = "APPROVE"
            decision_code = f"MUTEX_CUTOFF_{entry_reason}"
            record_telemetry(ticker, "⏸️ BLOCKED", decision_code)
        elif not match:
            final_state = "BLOCKED"
            hero_decision = "APPROVE"
            decision_code = "NO_LIQUID_CONTRACT_FOUND"
            record_telemetry(ticker, "⏸️ BLOCKED", decision_code)
        elif match["symbol"] in held_symbols:
            final_state = "BLOCKED"
            hero_decision = "APPROVE"
            decision_code = "CONTRACT_ALREADY_HELD"
            record_telemetry(ticker, "⏸️ BLOCKED", decision_code)
        elif qty < 1:
            final_state = "BLOCKED"
            hero_decision = "APPROVE"
            decision_code = "SIZING_BELOW_MINIMUM"
            record_telemetry(ticker, "⏸️ BLOCKED", decision_code)
        else:
            final_state = "ARMED"
            hero_decision = "APPROVE"
            decision_code = "ALL_GATES_PASSED"

        try:
            candidate_rec = lt.create_candidate_record(
                ticker=ticker,
                direction=direction,
                spot=spot,
                orb_high=orb_h,
                orb_low=orb_l,
                vwap=vwap,
                ema20_15m=feat["ema20"],
                ema20_slope_15m=slope,
                atr_15m=atr,
                rvol_ratio=rvol.get("ratio", 1.0),
                rvol_percentile=rvol.get("percentile", 50.0),
                rvol_zscore=rvol.get("zscore", 0.0),
                rs_market=reg.get("rs_market", 0.0),
                rs_sector=reg.get("rs_sector", 0.0),
                sector_etf=assigned_sector,
                breakout_body_pct=feat.get("body_pct", 0.0),
                close_location_val=feat.get("close_location", 0.0),
                compression_score=bd.get("compression", 0.0),
                hero_alpha_score=alpha_score,
                hero_decision=hero_decision,
                hero_reason_code=decision_code,
                vic_verdict=vic_clearance["verdict"],
                vic_sizing_scalar=vic_clearance["sizing_scalar"],
                vic_reason_code=vic_clearance["reason_code"],
                vic_obstacle_distance_r=vic_clearance["obstacle_distance_r"],
                contract_symbol=match["symbol"] if match else "NONE",
                strike=match["strike"] if match else 0.0,
                expiration=match.get("expiration", "") if match else "",
                dte=match.get("dte", 0) if match else 0,
                delta=match["delta"] if match else 0.0,
                bid=match["bid"] if match else 0.0,
                ask=match["ask"] if match else 0.0,
                mid=match["mid"] if match else 0.0,
                spread_pct=match["spread_pct"] * 100.0 if match else 0.0,
                execution_score=88.0 if match else 0.0,
                final_state=final_state,
                decision_code=decision_code,
                risk_budget_dollars=equity * RISK_PER_TRADE_PERCENT,
                base_qty=base_qty,
                vic_adjusted_qty=qty,
            )
            lt.append_candidate_to_log(candidate_rec)
        except Exception as lt_err:
            print(f"⚠️ LEARN tracking record error: {lt_err}")

        if final_state != "ARMED":
            continue

        tag = "🚀 [BULLISH ORB]" if is_bullish else "🔻 [BEARISH ORB]"
        print(f"{tag} {ticker} | Spot: ${spot:.2f} | Alpha Score: {alpha_score}/100")
        print(f"   Selected: {match['symbol']} (Delta: {match['delta']:.2f}, Mid: ${match['mid']:.2f}) | Sizing: {qty} contracts")

        order_cooldown_tracker[ticker] = time.time()
        order_id = None

        if trading_client:
            try:
                order = LimitOrderRequest(
                    symbol=match["symbol"],
                    qty=qty,
                    side=OrderSide.BUY,
                    time_in_force=TimeInForce.DAY,
                    limit_price=match["mid"],
                )
                res = trading_client.submit_order(order)
                order_id = res.id
            except Exception as oe_err:
                print(f"⚠️ Order submission error for {ticker}: {oe_err}")
                continue

        state_label = "🟠 PENDING (Limit Working)" if order_id else "🟡 ARMED (Breakout Triggered)"
        record_telemetry(
            ticker, 
            state_label, 
            f"Alpha: {alpha_score:.0f} | 4H Obstacle: {vic_clearance['obstacle_distance_r']}R | Midpoint Limit: ${match['mid']:.2f}",
            {"contract": match["symbol"], "levels": f"Stop: ${stop_level:.2f} | Target: ${target_level:.2f}"}
        )

        pending_setups[ticker] = {
            "contract": match["symbol"],
            "direction": direction,
            "entry_spot": spot,
            "entry_mid": match["mid"],
            "stop": stop_level,
            "target": target_level,
            "orb_high": orb_h,
            "orb_low": orb_l,
            "atr": atr,
            "alpha_score": alpha_score,
            "exec_score": 88.0,
            "dte": match.get("dte", 5),
            "spread_pct": match["spread_pct"] * 100.0,
            "order_id": order_id,
            "status": "ARMED",
            "bars_elapsed": 0,
            "vic_verdict": vic_clearance["verdict"],
            "vic_mode": vic_clearance["mode"],
            "vic_sizing_scalar": vic_clearance["sizing_scalar"],
            "vic_reason_code": vic_clearance["reason_code"],
            "vic_reason": vic_clearance["reason"],
            "vic_obstacle_dist_r": vic_clearance["obstacle_distance_r"],
            "vic_1h_bar_ts": vic_clearance["data_timestamp_1h"],
            "vic_4h_bar_ts": vic_clearance["data_timestamp_4h"],
        }

        rl.log_shadow_record(
            ticker=ticker,
            action="TRADE_ARMED",
            spot_price=spot,
            orb_high=orb_h,
            orb_low=orb_l,
            vwap=vwap,
            ema20=feat["ema20"],
            ema_slope=slope,
            atr=atr,
            rvol_ratio=rvol.get("ratio", 1.0),
            rvol_percentile=rvol.get("percentile", 50.0),
            rvol_zscore=rvol.get("zscore", 0.0),
            spy_score=reg.get("spy_score", 50.0),
            qqq_score=reg.get("qqq_score", 50.0),
            sector_etf=assigned_sector,
            sector_score=reg.get("sector_score", 50.0),
            rs_market=reg.get("rs_market", 0.0),
            rs_sector=reg.get("rs_sector", 0.0),
            volatility_regime=reg.get("volatility_regime", "NORMAL"),
            alpha_score=alpha_score,
            alpha_breakdown=bd,
            vic_verdict=vic_clearance["verdict"],
            vic_mode=vic_clearance["mode"],
            vic_sizing_scalar=vic_clearance["sizing_scalar"],
            vic_reason_code=vic_clearance["reason_code"],
            vic_reason=vic_clearance["reason"],
            vic_obstacle_dist_r=vic_clearance["obstacle_distance_r"],
            vic_1h_bar_ts=vic_clearance["data_timestamp_1h"],
            vic_4h_bar_ts=vic_clearance["data_timestamp_4h"],
            contract_symbol=match["symbol"],
            delta=match["delta"],
            dte=match.get("dte", 5),
            bid=match["bid"],
            ask=match["ask"],
            spread_pct=match["spread_pct"] * 100.0,
            execution_score=88.0,
            trade_taken=True,
            entry_price=spot,
        )


if __name__ == "__main__":
    print("🤖 Research Momentum Options Bot Active (Production Shadow Mode).")
    print("🏛️ Autonomous Risk & Operations: VIC AI Gatekeeper Engaged.")
    print("🧪 Unified Learning Engine: LEARN Tracker Active.")

    while True:
        try:
            if not is_regular_market_hours():
                print("\n🌙 Outside Regular Market Hours. Standby polling...")
                time.sleep(120)
                continue

            run_continuous_risk_loop()

            now_et = datetime.now(EASTERN_TZ)
            if now_et.minute % 5 == 0 and now_et.second <= 15:
                scan_alpha_signals()
                time.sleep(20)

            time.sleep(10)

        except KeyboardInterrupt:
            print("\n🛑 Bot terminated.")
            break
        except Exception as e:
            print(f"⚠️ Main loop error: {e}")
            time.sleep(15)