from alpaca.trading.client import TradingClient
from alpaca.trading.enums import OrderSide, TimeInForce
from alpaca.trading.requests import MarketOrderRequest

# Authenticate with your paper credentials
API_KEY = "PKN7VKUIZWPJI30QDSMTFU5VEB"
SECRET_KEY = "HxB7awxyAUVkahEKg8KJHk1uHQBnL9p11Rjw7kSucnth"  # Keep your secret key inside quotes

client = TradingClient(API_KEY, SECRET_KEY, paper=True)

# Define a fractional Bitcoin order ($25 notional or fractional qty like 0.001)
crypto_order = MarketOrderRequest(
    symbol="BTC/USD",
    qty=0.001,  # Fraction of 1 Bitcoin
    side=OrderSide.BUY,
    time_in_force=TimeInForce.GTC,  # Crypto requires GTC, not DAY
)

# Submit order
order = client.submit_order(order_data=crypto_order)

print("--- Crypto Order Executed ---")
print(f"Order ID: {order.id}")
print(f"Pair:     {order.symbol}")
print(f"Quantity: {order.qty} BTC")
print(f"Status:   {order.status}")
print("-----------------------------")